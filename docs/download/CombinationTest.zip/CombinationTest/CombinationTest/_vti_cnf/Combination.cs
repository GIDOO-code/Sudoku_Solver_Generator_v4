vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|11 Feb 2017 15:28:27 -0000
vti_extenderversion:SR|12.0.0.0
vti_cacheddtm:TX|10 Apr 2015 09:47:22 -0000
vti_filesize:IR|1987
vti_backlinkinfo:VX|
vti_modifiedby:SR|jk5\\jk
